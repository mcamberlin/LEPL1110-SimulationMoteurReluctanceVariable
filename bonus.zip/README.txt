Des modifications graphiques ont été efectuées:

- D'abord en maintenant (MAJ + E), on peut apercevoir les propriétés dynamiques du moteur (son couple, sa vitesse angulaire, ...)

- Ensuite, en maintenant (MAJ + K), on peut apercevoir au cours du temps quelles sont les bobines qui sont allumées. Une bobine de couleur rouge indique qu'elle est parcourue par une densité de courant positive, une noire une densité de courant négative et une non colorées par une densité de courant nulle.

- Enfin, au démarrage de la simulation, la console vous demande quel type de solver utiliser (2 choix: gaussien ou bande).



Liens podcast:
https://uclouvain-my.sharepoint.com/:v:/g/personal/merlin_camberlin_student_uclouvain_be/ESyZKaa5WQ1Ngv1VizdpmrkB6gfUxu8XDkuZ798GMn-LQg?e=85Rfss

https://youtu.be/kxhXLU8uCjM

